# USports Hoops Scraper

## Introduction

This package makes getting data from https://usportshoops.ca/ easy. Provided in the package are web scraping methods to quickly pull individual game or season box scores.

